@echo off
setlocal

set "APP_HOME=%~dp0"
if defined JAVA_HOME (
    set "JAVA_EXE=%JAVA_HOME%\bin\java.exe"
    if not exist "%JAVA_EXE%" goto noJava
) else (
    set "JAVA_EXE=java.exe"
    where java.exe >nul 2>nul || goto noJava
)

"%JAVA_EXE%" -Dorg.gradle.appname=gradlew -classpath "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
set "EXIT_CODE=%ERRORLEVEL%"
endlocal & exit /b %EXIT_CODE%

:noJava
echo ERROR: Java was not found. Set JAVA_HOME or add java.exe to PATH. 1>&2
endlocal & exit /b 1

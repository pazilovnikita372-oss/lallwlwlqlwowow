package com.oxide.launcher.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsStore by preferencesDataStore(name = "oxide_settings")

data class OxideSettings(
    val neonIntensity: Float = 1.0f,
    val animationsEnabled: Boolean = true,
    val selectedSkinId: String = "default",
    val language: String = "ru"
)

class SettingsRepository(private val context: Context) {

    private val KEY_NEON      = floatPreferencesKey("neon_intensity")
    private val KEY_ANIMS     = booleanPreferencesKey("animations_enabled")
    private val KEY_SKIN      = stringPreferencesKey("selected_skin")
    private val KEY_LANG      = stringPreferencesKey("language")

    val settings: Flow<OxideSettings> = context.settingsStore.data.map { prefs ->
        OxideSettings(
            neonIntensity     = prefs[KEY_NEON]  ?: 1.0f,
            animationsEnabled = prefs[KEY_ANIMS] ?: true,
            selectedSkinId    = prefs[KEY_SKIN]  ?: "default",
            language          = prefs[KEY_LANG]  ?: "ru"
        )
    }

    suspend fun updateSettings(s: OxideSettings) {
        context.settingsStore.edit {
            it[KEY_NEON]  = s.neonIntensity
            it[KEY_ANIMS] = s.animationsEnabled
            it[KEY_SKIN]  = s.selectedSkinId
            it[KEY_LANG]  = s.language
        }
    }
}

package com.oxide.launcher.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.ui.res.painterResource
import com.oxide.launcher.R
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.oxide.launcher.ui.components.*
import com.oxide.launcher.ui.navigation.Screen
import com.oxide.launcher.ui.theme.*
import com.oxide.launcher.viewmodel.OxideViewModel

@Composable
fun SettingsScreen(
    navController: NavHostController,
    viewModel: OxideViewModel
) {
    val uiState by viewModel.uiState.collectAsState()
    val s = uiState.settings

    OxideBackground {
        Column(
            Modifier
                .fillMaxSize()
                .systemBarsPadding()
        ) {
            OxideTopBar(title = "НАСТРОЙКИ", onBack = { navController.popBackStack() })
            NeonDivider()

            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Section: Visual
                SettingsSection("ВИЗУАЛ") {
                    SettingsSlider(
                        icon    = Icons.Default.Tungsten,
                        label   = "Яркость неона",
                        value   = s.neonIntensity,
                        onValueChange = { viewModel.updateSettings(s.copy(neonIntensity = it)) }
                    )
                    SettingsToggle(
                        icon    = Icons.Default.Animation,
                        label   = "Анимации интерфейса",
                        checked = s.animationsEnabled,
                        onCheckedChange = { viewModel.updateSettings(s.copy(animationsEnabled = it)) }
                    )
                }

                // Section: Navigation shortcuts
                SettingsSection("БЫСТРЫЙ ДОСТУП") {
                    SettingsNavItem(
                        iconRes = R.drawable.ic_fn_profiles,
                        label   = "Профили устройства",
                        hint    = "${uiState.profiles.size} профиль(ей)"
                    ) { navController.navigate(Screen.Profiles.route) }

                    SettingsNavItem(
                        iconRes = R.drawable.ic_fn_skins,
                        label   = "Скины и оформление",
                        hint    = uiState.settings.selectedSkinId
                    ) { navController.navigate(Screen.Skins.route) }

                    SettingsNavItem(
                        iconRes = R.drawable.ic_fn_apps,
                        label   = "Приложения",
                        hint    = "${uiState.installedApps.size} установлено"
                    ) { navController.navigate(Screen.Apps.route) }
                }

                // Section: Language
                SettingsSection("ЯЗЫК") {
                    SettingsChips(
                        label = "Язык интерфейса",
                        options = listOf("ru" to "Русский", "en" to "English"),
                        selected = s.language,
                        onSelect = { viewModel.updateSettings(s.copy(language = it)) }
                    )
                }

                // Section: About
                SettingsSection("О ПРИЛОЖЕНИИ") {
                    SettingsNavItem(
                        iconRes = R.drawable.ic_fn_about,
                        label = "OXIDE — версия 1.0.0",
                        hint  = "Подробнее"
                    ) { navController.navigate(Screen.About.route) }
                }

                Spacer(Modifier.height(24.dp))
            }
        }

        uiState.snackMessage?.let { msg ->
            Snackbar(
                modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp),
                action = { TextButton(onClick = { viewModel.clearSnack() }) { Text("OK") } }
            ) { Text(msg) }
        }
    }
}

@Composable
private fun SettingsSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column {
        Text(
            title,
            fontSize      = 10.sp,
            letterSpacing = 2.sp,
            color         = OxideTextSecond,
            modifier      = Modifier.padding(start = 4.dp, bottom = 6.dp, top = 4.dp)
        )
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            content()
        }
        Spacer(Modifier.height(4.dp))
    }
}

@Composable
private fun SettingsToggle(
    icon: ImageVector,
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = OxideNeonBlue, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(12.dp))
        Text(label, Modifier.weight(1f), fontSize = 14.sp, color = OxideTextPrimary)
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor  = OxideDeepBlack,
                checkedTrackColor  = OxideNeonBlue,
                uncheckedTrackColor = OxideGlassBorder
            )
        )
    }
}

@Composable
private fun SettingsSlider(
    icon: ImageVector,
    label: String,
    value: Float,
    onValueChange: (Float) -> Unit
) {
    Column(Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = OxideNeonBlue, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(12.dp))
            Text(label, Modifier.weight(1f), fontSize = 14.sp, color = OxideTextPrimary)
            Text("${(value * 100).toInt()}%", fontSize = 12.sp, color = OxideNeonBlue)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            colors = SliderDefaults.colors(
                thumbColor        = OxideNeonBlue,
                activeTrackColor  = OxideNeonBlue,
                inactiveTrackColor = OxideGlassBorder
            ),
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}

@Composable
private fun SettingsNavItem(
    iconRes: Int,
    label: String,
    hint: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(painterResource(iconRes), contentDescription = null, modifier = Modifier.size(38.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(label, fontSize = 14.sp, color = OxideTextPrimary)
            if (hint.isNotEmpty()) Text(hint, fontSize = 11.sp, color = OxideTextSecond)
        }
        IconButton(onClick = onClick) {
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = OxideTextSecond)
        }
    }
}

@Composable
private fun SettingsChips(
    label: String,
    options: List<Pair<String, String>>,
    selected: String,
    onSelect: (String) -> Unit
) {
    Column(Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
        Text(label, fontSize = 13.sp, color = OxideTextSecond, modifier = Modifier.padding(bottom = 8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { (key, display) ->
                FilterChip(
                    selected = selected == key,
                    onClick  = { onSelect(key) },
                    label    = { Text(display, fontSize = 12.sp) },
                    colors   = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = OxideNeonBlue.copy(0.25f),
                        selectedLabelColor     = OxideNeonBlue,
                        containerColor         = OxideGlassWhite,
                        labelColor             = OxideTextSecond
                    )
                )
            }
        }
    }
}
